# FoodFlow — Online Food Order Processing System (MP1)

A Flask web app mini project demonstrating a FIFO (first-in, first-out) order processing queue.

## Features
- Menu with item quantities and customer name
- SQLite-backed order records
- Orders dashboard and status updates
- Python `collections.deque` view of pending orders
- Responsive layout and input validation

## Run locally
1. Install Python 3.10+.
2. Create and activate a virtual environment.
3. Run `pip install -r requirements.txt`.
4. Run `python app.py`.
5. Open http://127.0.0.1:5000.

## Project structure
- `app.py`: routes, SQLite operations, FIFO queue
- `templates/`: HTML templates
- `static/style.css`: responsive styling
- `tests/`: test plan placeholder

## Academic note
This is a classroom demonstration only. It does not accept payments or connect to a real restaurant. Replace the development secret key and disable debug mode before any public deployment.
