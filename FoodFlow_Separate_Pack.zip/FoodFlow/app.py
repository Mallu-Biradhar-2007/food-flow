from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3, os
from collections import deque
from datetime import datetime

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-for-production")
DB = os.path.join(os.path.dirname(__file__), "foodflow.db")

MENU = [
    {"id": 1, "name": "Margherita Pizza", "category": "Pizza", "price": 249, "emoji": "🍕", "desc": "Classic tomato, mozzarella and basil."},
    {"id": 2, "name": "Veggie Burger", "category": "Burgers", "price": 159, "emoji": "🍔", "desc": "Grilled patty, crisp lettuce and house sauce."},
    {"id": 3, "name": "Paneer Wrap", "category": "Wraps", "price": 179, "emoji": "🌯", "desc": "Spiced paneer with fresh vegetables."},
    {"id": 4, "name": "Masala Fries", "category": "Sides", "price": 99, "emoji": "🍟", "desc": "Golden fries tossed with house masala."},
    {"id": 5, "name": "Cold Coffee", "category": "Drinks", "price": 119, "emoji": "🥤", "desc": "Chilled coffee with a creamy finish."},
    {"id": 6, "name": "Chocolate Brownie", "category": "Desserts", "price": 129, "emoji": "🍫", "desc": "Warm chocolate brownie."},
]

def connect():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    with connect() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT, customer TEXT NOT NULL,
            items TEXT NOT NULL, total INTEGER NOT NULL, status TEXT NOT NULL,
            created_at TEXT NOT NULL, queue_order INTEGER NOT NULL)""")
init_db()

# Explicit FIFO queue: the database is the durable source of truth; deque models pending order.
def pending_queue():
    with connect() as con:
        rows = con.execute("SELECT id FROM orders WHERE status IN ('Received','Preparing') ORDER BY queue_order ASC").fetchall()
    return deque(row["id"] for row in rows)

@app.route("/")
def index():
    return render_template("index.html", menu=MENU)

@app.post("/order")
def order():
    customer = request.form.get("customer", "").strip()
    try:
        ids = request.form.getlist("item_id")
        quantities = request.form.getlist("quantity")
        cart = []
        for raw_id, raw_qty in zip(ids, quantities):
            item = next((x for x in MENU if str(x["id"]) == raw_id), None)
            qty = int(raw_qty)
            if item and 1 <= qty <= 20:
                cart.append((item, qty))
        if not customer or not cart:
            raise ValueError
    except (ValueError, TypeError):
        flash("Enter your name and choose at least one valid item.", "error")
        return redirect(url_for("index"))
    total = sum(item["price"] * qty for item, qty in cart)
    summary = "; ".join(f"{item['name']} x{qty}" for item, qty in cart)
    with connect() as con:
        cur = con.execute("INSERT INTO orders(customer,items,total,status,created_at,queue_order) VALUES(?,?,?,?,?,?)",
            (customer, summary, total, "Received", datetime.now().isoformat(timespec="minutes"), int(datetime.now().timestamp()*1000)))
        order_id = cur.lastrowid
    flash(f"Order #{order_id} received! Orders are processed in FIFO order.", "success")
    return redirect(url_for("orders"))

@app.route("/orders")
def orders():
    with connect() as con:
        rows = con.execute("SELECT * FROM orders ORDER BY queue_order DESC").fetchall()
    return render_template("orders.html", orders=rows, queue=list(pending_queue()))

@app.post("/orders/<int:order_id>/status")
def update_status(order_id):
    status = request.form.get("status")
    if status not in {"Received", "Preparing", "Ready", "Completed", "Cancelled"}:
        flash("Invalid status.", "error")
    else:
        with connect() as con:
            con.execute("UPDATE orders SET status=? WHERE id=?", (status, order_id))
        flash(f"Order #{order_id} updated to {status}.", "success")
    return redirect(url_for("orders"))

@app.route("/health")
def health():
    return {"status": "ok", "app": "FoodFlow"}

if __name__ == "__main__":
    app.run(debug=True)
