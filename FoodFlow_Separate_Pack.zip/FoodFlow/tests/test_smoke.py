import unittest, tempfile, os
import app as food_app

class FoodFlowSmokeTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.NamedTemporaryFile(delete=False)
        self.tmp.close()
        food_app.DB = self.tmp.name
        food_app.init_db()
        self.client = food_app.app.test_client()
    def tearDown(self):
        os.unlink(self.tmp.name)
    def test_home(self):
        self.assertEqual(self.client.get("/").status_code, 200)
    def test_health(self):
        self.assertEqual(self.client.get("/health").json["status"], "ok")

if __name__ == "__main__": unittest.main()
